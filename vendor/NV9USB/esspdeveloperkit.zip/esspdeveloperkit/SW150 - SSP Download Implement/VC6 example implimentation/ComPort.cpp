
/*-------------------------------------------------------------------------------------------------
|						Innovative Technology Ltd
|								ComPort.c
|					Windows communication port functions
|
|
|---------------------------------------------------------------------------------------------------*/



#include "stdafx.h"
#include "ComPort.h"
#include <stdio.h>
#pragma comment(lib,"advapi32.lib")


