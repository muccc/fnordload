#ifndef _CTARGET_UPDATE_H
#define _CTARGET_UPDATE_H

#include "defTypes.h"



int16 EstablishSSPComms(SSP_DOWNLOAD* sspD);
int32 DownloadSSPFile(SSP_DOWNLOAD* sspD);




#endif

