

#include "stdafx.h"
#include "PayoutCommands.h"
#include "ssp.h"
#include <windows.h>

extern SSP_COMMAND sspC;
extern SSP_COMMAND_INFO	sspI;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Function to set up the smart payout for payin-payout of notes
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int EnablePayout(PAYOUT_DATA* py)
{
	int i,j;

	/* enable the payout device  */
	sspC.EncryptionStatus = 1;     // note here we are using encrpyted SSP by setting this flag
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_ENABLE_PAYOUT_DEVICE;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command ENABLE PAYOUT to slave\n");
		return 0;
	}

	/* set all the values to be stored in the payout for this demo - the use can set individual values to his requirements */
	for(i = 0; i < py->NumberOfValues; i++){
		sspC.EncryptionStatus = 1;     
		sspC.CommandDataLength = 6;
		sspC.CommandData[0] = cmd_SSP_SET_NOTE_ROUTE;
		sspC.CommandData[1] = ROUTE_STORED;
		for(j = 0; j < 4; j++) /* add in the value to count  */
			sspC.CommandData[2 + j] = (unsigned char)(py->Values[i] >> (8*j));  

		if(SendSSPCommand(&sspC,&sspI) == 0){
			printf("ERROR: Error sending command cmd_SSP_SET_NOTE_ROUTE to slave\n");
			return 0;
		}		
	}

	
	/* this to ensure protcol version 4events are shown  */
	sspC.EncryptionStatus = 1;  
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_ENABLE_PROTOCOL_VER_EVENTS;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command cmd_ENABLE_PROTOCOL_VER_EVENTS to slave\n");
		return 0;
	}

	sspC.EncryptionStatus = 1;     
	sspC.CommandDataLength = 3;
	sspC.CommandData[0] = cmd_SSP_SET_BNV_INHIBITS;
	sspC.CommandData[1] = 0xFF;  /* set all 16 channel to enable in this example */
	sspC.CommandData[2] = 0xFF; 
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command cmd_SSP_SET_BNV_INHIBITS to slave\n");
		return 0;
	}

	sspC.EncryptionStatus = 1;     // note here we are using encrpyted SSP by setting this flag
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_SSP_ENABLE;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command ENABLE to slave\n");
		return 0;
	}

	return 1;

}


////////////////////////////////////////////////////////////////////////////////////
//  Function to obtain payout data (note denimoniations and country etc)
///////////////////////////////////////////////////////////////////////////////////////
int GetPayoutData(PAYOUT_DATA* py)
{
	unsigned int i;
	unsigned long valueMultiplier;
	/* send setup request command  */
	sspC.EncryptionStatus = 1; 
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_SSP_SETUP_REQUEST;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command cmd_SSP_SETUP_REQUEST to slave\n");
		return 0;
	}
	/* get BNV setup data from the ssp response  */
	for(i = 0; i < 4; i++)
		py->FirmwareVersion[i] = sspC.ResponseData[i + 2];

	py->NumberOfValues = sspC.ResponseData[12];
	valueMultiplier = 0;
	py->TrueValueMultiplier = 0;
	for(i = 0; i < 3; i++){
		py->CountryCode[i] = sspC.ResponseData[i + 6];  
		valueMultiplier += ((unsigned long)sspC.ResponseData[i + 9] << (8*(2-i)));
		py->TrueValueMultiplier += ((unsigned long)sspC.ResponseData[i + 13 + (py->NumberOfValues * 2)] << (8*(2-i)));
	}
	/* null terminate for string display  */
	py->FirmwareVersion[4] = '\0';
	py->CountryCode[3] = '\0'; 
	/* check for obselete payout value */
	if(py->TrueValueMultiplier == 0){
		printf("Payout firmware out-of-date. Please update to latest value\n");
		return 0;
	}
	/* update value array  */
	for(i = 0; i < py->NumberOfValues; i++){
		py->Values[i] = (unsigned long)sspC.ResponseData[i + 13] * py->TrueValueMultiplier * valueMultiplier; 
	}


	return 1;

}

////////////////////////////////////////////////////////////////////////////////////
//  Function to update the counters with the stored note counts and routes 
///////////////////////////////////////////////////////////////////////////////////////
int GetPayoutCountData(PAYOUT_DATA* py)
{
	int i,j;

	py->TotalStoredValue = 0;
	for(i = 0; i < py->NumberOfValues; i++){
		sspC.EncryptionStatus = 1;   
		sspC.CommandDataLength = 5;
		sspC.CommandData[0] = cmd_SSP_GET_NOTE_AMOUNT;
		for(j = 0; j < 4; j++) /* add in the value to count  */
			sspC.CommandData[1 + j] = (unsigned char)(py->Values[i] >> (8*j));  
		if(SendSSPCommand(&sspC,&sspI) == 0){
			printf("ERROR: Error sending command cmd_SSP_GET_NOTE_AMOUNT to slave\n");
			return 0;
		}	
		py->ValueCount[i] = 0;
		for(j = 0; j < 2; j++)
			py->ValueCount[i] += (unsigned long)sspC.ResponseData[j + 1] << (8*j); 

		py->TotalStoredValue += (py->ValueCount[i] * py->Values[i])/py->TrueValueMultiplier;  

		sspC.EncryptionStatus = 1;   
		sspC.CommandDataLength = 5;
		sspC.CommandData[0] = cmd_SSP_GET_NOTE_ROUTE;
		for(j = 0; j < 4; j++) /* add in the value to count  */
			sspC.CommandData[1 + j] = (unsigned char)(py->Values[i] >> (8*j));  
		if(SendSSPCommand(&sspC,&sspI) == 0){
			printf("ERROR: Error sending command cmd_SSP_GET_NOTE_ROUTE to slave\n");
			return 0;
		}	
		py->NoteRoutes[i] = sspC.ResponseData[1]; 

	}
	/* display the updated counts and values */
	printf("\nUpdated Payout Count:\n");
	for(i = 0; i < py->NumberOfValues; i++)
		printf("%s %d %d\n",py->CountryCode,py->Values[i]/py->TrueValueMultiplier,py->ValueCount[i]);   
	printf("Total Stored Value: %s %d\n",py->CountryCode,py->TotalStoredValue);  
	
	return 1;

}
////////////////////////////////////////////////////////////////////////////////////
//  Function to Poll the payout device and display events/responses
///////////////////////////////////////////////////////////////////////////////////////
int PollPayoutDevice(PAYOUT_DATA* py)
{
	unsigned long i,payOutValue,reqValue,j;
	BOOL updateCount = false;

	/* send the poll command  */
	sspC.EncryptionStatus = 1; 
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_SSP_POLL;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command POLL to slave\n");
		return 0;
	}	
	
	/* loop event response and act on events replied  */
	for(i = 1; i < sspC.ResponseDataLength; i++){
			switch(sspC.ResponseData[i]){
			case hp_rsp_RESET:
				printf("Event: RESET\n");
				break	;
			case hp_rsp_DISABLED:
				printf("Event: DISABLED\n");
				break;
			case  hp_rsp_READNOTE:
				if(sspC.ResponseData[i + 1] > 0)
					printf("Event: NOTE READ %s %d\n",py->CountryCode,py->Values[sspC.ResponseData[i + 1] - 1]/py->TrueValueMultiplier);
				i++;
				break;
			case  hp_rsp_NOTE_CREDIT:
				printf("\nEvent: NOTE CREDIT %s %d\n",py->CountryCode,py->Values[sspC.ResponseData[i + 1] - 1]/py->TrueValueMultiplier);	
				i++;
				break;
			case  hp_rsp_REJECTING:
				printf(".");
				break;
			case  hp_rsp_REJECTED:
				printf("Event: REJECTED\n");
				break;
			case  hp_rsp_STACKING:
				printf(".");
				break;
			case  hp_rsp_STACKED:
				printf("\nEvent: NOTE STACKED\n");
				updateCount = true;
				break;
			case  hp_rsp_SAFE_JAM:

				break;
			case  hp_rsp_UNSAFE_JAM:
				break;
			case  hp_rsp_STACKER_FULL:
				break;
			case  hp_rsp_NOTE_CLEARED_FRONT:
				break;
			case  hp_rsp_NOTE_CLEARED_CASHBOX:
				break;
			case  hp_rsp_CASHBOX_REMOVED:
				printf("Event: CASHBOX REMOVED\n");					
				break;
			case  hp_rsp_CASHBOX_REPLACED:
				printf("Event: CASHBOX REPLACED\n");	
				break;
			case  hp_rsp_BARCODE_TICKET_VALIDATED:
				break;
			case  hp_rsp_BARCODE_TICKET_ACK:
				break;
			case hp_rsp_DISPENSING:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				printf("Event: DISPENSING %d\n",payOutValue);
				i += 4;
				break;
			case hp_rsp_DISPENSED:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				printf("Event: DISPENSED %d\n",payOutValue);
				/* after dispensing, we need to re-enable */
				sspC.EncryptionStatus = 1;   
				sspC.CommandDataLength = 1;
				sspC.CommandData[0] = cmd_SSP_ENABLE;
				if(SendSSPCommand(&sspC,&sspI) == 0){
					printf("ERROR: Error sending command ENABLE to slave\n");
					return 0;
				}
				updateCount = true;
				i += 4;
				break;
			case hp_rsp_HALTED:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				printf("Event: HALTED %d\n",payOutValue);
				updateCount = true;
				i += 4;
				break;
			case hp_FLOATING:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				printf("Event: FLOATING %d\n",payOutValue);
				i += 4;
				break;
			case hp_FLOATED:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				printf("Event: FLOATED %d\n",payOutValue);
				i += 4;
				updateCount = true;
				break;
			case hp_TIME_OUT:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				printf("Event: TIMEOUT %d\n",payOutValue);
				i += 4;
				updateCount = true;
				break;
			case hp_EMPTYING:
				printf(".");
				break;
			case hp_EMPTYED:
				printf("\nEvent: EMPTYED\n");
				updateCount = true;
				break;
			case hp_rsp_NOTE_STORED:
				printf("Event: NOTE STORED\n");
				updateCount = true;
				break;
			case hp_INPCOMPLETE_PAYOUT:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				reqValue = 0;
				for(j = 0; j <4; j++)
					reqValue += ((unsigned long)sspC.ResponseData[i + j + 1 + 4]) << (8*j);
				reqValue /= py->TrueValueMultiplier;
				printf("Event: INCOMPLETE PAYOUT - Amount paid: %d Amount Requested: %d\n",payOutValue,reqValue);
				i += 8;
				break;
			case hp_INPCOMPLETE_FLOAT:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				reqValue = 0;
				for(j = 0; j <4; j++)
					reqValue += ((unsigned long)sspC.ResponseData[i + j + 1 + 4]) << (8*j);
				reqValue /= py->TrueValueMultiplier;
				printf("Event: INCOMPLETE FLOAT - Amount paid: %d Amount Requested: %d\n",payOutValue,reqValue);
				i += 8;
				break;
			case hp_rsp_FRAUD_ATTEMPT:
				payOutValue = 0;
				for(j = 0; j <4; j++)
					payOutValue += ((unsigned long)sspC.ResponseData[i + j + 1]) << (8*j);
				payOutValue /= py->TrueValueMultiplier;
				printf("Event: FRAUD ATTEMPT %d\n",payOutValue);
				i += 4;
				updateCount = true;
				break;
			default:
				printf("UNKWOWN EVENT %d\n",sspC.ResponseData[i]);
			}

	}
	/* do we need to update the counts ? */
	if(updateCount){
		if(GetPayoutCountData(py) == 0){
			return 0;
		}

	}

	

	return 1;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Function to command slave smart hopper to pay value out - encryption keys must be set first
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int SetPayOutAmount(unsigned long payAmount)
{

	int i;

	/* may need to re-enable system here due to poll timeout  */
	sspC.EncryptionStatus = 1;     
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_SSP_ENABLE;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command ENABLE to slave\n");
		return 0;

	}
	sspC.EncryptionStatus = 1;     
	sspC.CommandDataLength = 5;
	sspC.CommandData[0] = cmd_SET_PAY_OUT_AMOUNT;
	for(i = 0 ; i < 4; i++)
		sspC.CommandData[i + 1] = (unsigned char)(payAmount >> 8*i);


	switch(SendSSPCommand(&sspC,&sspI)){
	 case 0:
		printf("ERROR: Error sending command SET_PAY_OUT_AMOUNT to slave\n");
		return 0;
	 break;
	 case NOT_ENOUGH_VALUE:
	    printf("NOT_ENOUGH_VALUE response to payout command\n");
	 break;
	 case CANNOT_PAY_EXACT_AMOUNT:
		printf("CANNOT_PAY_EXACT_AMOUNT response to payout command\n");
	 break;
	 case PAYOUT_BUSY:
		printf("PAYOUT_BUSY response to payout command\n");
	 break;
	 case PAYOUT_DISABLED:
		 printf("PAYOUT_DISABLED response to payout command\n");
	 break;
	}


	return 1;

}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Function to command slave smart hopper to pay value out - encryption keys must be set first
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int EmptyPayout(void)
{


	/* may need to re-enable system here due to poll timeout  */
	sspC.EncryptionStatus = 1;     
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_SSP_ENABLE;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command ENABLE to slave\n");
		return 0;

	}
	sspC.EncryptionStatus = 1;     
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_EMPTY_PAYOUT;

	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command cmd_EMPTY_PAYOUT to slave\n");
		return 0;

	}


	return 1;

}

