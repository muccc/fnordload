// CsspEncryptionDemo.cpp : Defines the entry point for the console application.


#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <conio.h>
#include "payoutcommands.h"
#include "ssp.h"


#define HOST_ENC_KEY										0x0123456701234567
#define VERSION_INFO										"1.0.1"


/* local function headers		*/
int NegotiateKeyExchange(unsigned __int64* hostKey);
int InitiateDLLFunctions(void);
void SetupSSPCommandStructure(SSP_COMMAND* ss);



/* DLL defs and references			*/
typedef UINT (CALLBACK* LPFNDLLFUNC1)(SSP_COMMAND* cmd);
LPFNDLLFUNC1 openPort;
typedef UINT (CALLBACK* LPFNDLLFUNC2)(void);
LPFNDLLFUNC2 closePort;
typedef UINT (CALLBACK* LPFNDLLFUNC3)(SSP_COMMAND* cmd,SSP_COMMAND_INFO* sspInfo);
LPFNDLLFUNC3 sspSendCommand;
typedef UINT (CALLBACK* LPFNDLLFUNC4)(SSP_KEYS* key, SSP_COMMAND* cmd);
LPFNDLLFUNC4 initiateSSPHostKeys;
typedef UINT (CALLBACK* LPFNDLLFUNC5)(SSP_KEYS* key);
LPFNDLLFUNC5 createSSPHostEncryptionKey;



/* module variables   */

HINSTANCE hinstLib;
PAYOUT_DATA pay;
SSP_COMMAND sspC;
SSP_COMMAND_INFO	sspI;

/* module functions  */

////////////////////////////////////////////////////////////////////////////////////////////////////
//  Main function - entry point
/////////////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char* argv[])
{
	unsigned char exitLoop = 0;
	int payoutValue;


	/* check command line args  */
	if(argc != 2){
		printf("No command line argments seen. Start program with CsspEncryptionDemo [port number]\n");
		printf("Program exit: Press any key to close.");
		while(!_kbhit());
		return 1;
	}


	printf("Payout basic implimentation version %s\n",VERSION_INFO);

	/* get the ssp serial port number from the command line  */
	sspC.PortNumber = atoi(argv[1]);
	SetupSSPCommandStructure(&sspC);

	/* call function to load and reference the DLL functions  */
	if(InitiateDLLFunctions() == 0){
		return 1;
	}

	/* Check serial com connection and get encryption key */
	if(NegotiateKeyExchange(&sspC.Key.EncryptKey) == 0){
		closePort();
		printf("Program exit: Press any key to close.");
		while(!_kbhit());
		FreeLibrary(hinstLib);
		return 1;
	}
	printf("Encryption Key negotiated.\n");
	/* get the denimination data form the payout */
	printf("Getting payout data\n");
	if(GetPayoutData(&pay) == 0){
		closePort();
		printf("Program exit: Press any key to close.");
		while(!_kbhit());
		FreeLibrary(hinstLib);
		return 1;
	}
	/* get the notes values stored  */
	if(GetPayoutCountData(&pay) == 0){
		closePort();
		printf("Program exit: Press any key to close.");
		while(!_kbhit());
		FreeLibrary(hinstLib);
		return 1;
	}

	/* enable payout for operations  */
	if(EnablePayout(&pay) == 0){
		closePort();
		printf("Program exit: Press any key to close.");
		while(!_kbhit());
		FreeLibrary(hinstLib);
		return 1;
	}
	
	do{
		/* poll the payout device and check for events  */
		if(PollPayoutDevice(&pay) == 0){
			exitLoop = 1;
		}
		Sleep(100);
		if(_kbhit()){
			/* which command key was hit  */
			switch(getchar()){
			case 'x':  /* end run  */
			case 'X':
				exitLoop = 1;
			break;
			case 'p':  /* Payout a value  */
			case 'P':
				printf("Enter payout value: ");
				scanf_s("%d",&payoutValue);
				if(SetPayOutAmount((unsigned long)payoutValue * pay.TrueValueMultiplier) == 0){
					exitLoop = 1;
				}				
			break;
			case 'e': /* empty the payout  */
			case 'E':
				printf("\nEmptying command sent...\n");
				if(EmptyPayout()== 0){
					exitLoop = 1;
				}		
				/* enable payout for operations after emptying  */
				if(EnablePayout(&pay) == 0){
					exitLoop = 1;
				}
			break;
			case 'f':
			case 'F':
				/* TO DO - add function for float command  */
			break;


			}
		}


	}while(!exitLoop);


	closePort();
	
	printf("Program exit: Press any key to close.");
	while(!_kbhit());

	// Unload DLL lib
	FreeLibrary(hinstLib);
	

	return 0;
}


////////////////////////////////////////////////////////////////////////////////////
//  Function to initialise the global ssp comand structre with values   
///////////////////////////////////////////////////////////////////////////////////////
void SetupSSPCommandStructure(SSP_COMMAND* ss)
{

	ss->Key.FixedKey = HOST_ENC_KEY;
    ss->SSPAddress = 0;
    ss->BaudRate = 9600;
    ss->Timeout = 1000;
    ss->RetryLevel = 5;

	
}

//////////////////////////////////////////////////////////////////////////////////////
// Function to load the DLL library functions and create reference pointers to required functions
//////////////////////////////////////////////////////////////////////////////////////////////
int InitiateDLLFunctions(void)
{



	// Load DLL file
	hinstLib = LoadLibrary(TEXT("ITLSSPProc.dll"));
	if (hinstLib == NULL) {
		printf("ERROR: unable to load DLL\n");
		return 0;
	}

	openPort = (LPFNDLLFUNC1)GetProcAddress(hinstLib, "OpenSSPComPort");//
	if (openPort == NULL) {
		printf("ERROR: unable to find DLL function OpenSSPComPort\n");
		FreeLibrary(hinstLib);
		return 0;
	}

	closePort = (LPFNDLLFUNC2)GetProcAddress(hinstLib, "CloseSSPComPort");
	if (closePort == NULL) {
		printf("ERROR: unable to find DLL function CloseSSPComPort\n");
		FreeLibrary(hinstLib);
		return 0;
	}

	sspSendCommand = (LPFNDLLFUNC3)GetProcAddress(hinstLib, "SSPSendCommand");
	if (sspSendCommand == NULL) {
		printf("ERROR: unable to find DLL function SSPSendCommand\n");
		FreeLibrary(hinstLib);
		return 0;
	}
	initiateSSPHostKeys = (LPFNDLLFUNC4)GetProcAddress(hinstLib, "InitiateSSPHostKeys");
	if (initiateSSPHostKeys == NULL) {
		printf("ERROR: unable to find DLL function initiateSSPHostKeys\n");
		FreeLibrary(hinstLib);
		return 0;
	}
	createSSPHostEncryptionKey = (LPFNDLLFUNC5)GetProcAddress(hinstLib, "CreateSSPHostEncryptionKey");
	if (createSSPHostEncryptionKey == NULL) {
		printf("ERROR: unable to find DLL function createSSPHostEncryptionKey\n");
		FreeLibrary(hinstLib);
		return 0;
	}


	return 1;

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Function to comunicate with the slave and use the dll functions to set and mutal encryption key for host and slave
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
int NegotiateKeyExchange(unsigned __int64* hostKey)
{
	SSP_KEYS sKey;
	int i;


	// DLL call 
	if(initiateSSPHostKeys(&sKey,&sspC) == 0){
		printf("ERROR: Cannot Initiate host keys\n");
		return 0;
	}


	// DLL call to open a serial coms port
	if(openPort(&sspC) != 1){
		printf("ERROR: Cannot open serial communications port\n");
		return 0;
	}
	// send sync command to establish coms 
	sspC.EncryptionStatus = 0;
	sspC.CommandDataLength = 1;
	sspC.CommandData[0] = cmd_SSP_SYNC;
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending command to slave\n");
		return 0;

	}

	// set generator command
	sspC.EncryptionStatus = 0;
	sspC.CommandDataLength = 9;
	sspC.CommandData[0] = cmd_SSP_SET_GENERATOR;
	for(i = 0; i < 8; i++)
		sspC.CommandData[i + 1] = (unsigned char)(sKey.Generator >> (i*8));
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending GENERATOR command to slave\n");
		return 0;

	}
	// set modulus command
	sspC.EncryptionStatus = 0;
	sspC.CommandDataLength = 9;
	sspC.CommandData[0] = cmd_SSP_SET_MODULUS;
	for(i = 0; i < 8; i++)
		sspC.CommandData[i + 1] = (unsigned char)(sKey.Modulus >> (i*8));
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending MODULUS command to slave\n");
		return 0;

	}
	// req key exchange command
	sspC.EncryptionStatus = 0;
	sspC.CommandDataLength = 9;
	sspC.CommandData[0] = cmd_SSP_REQ_KEY_EXCHANGE;
	for(i = 0; i < 8; i++)
		sspC.CommandData[i + 1] = (unsigned char)(sKey.HostInter  >> (i*8));
	if(SendSSPCommand(&sspC,&sspI) == 0){
		printf("ERROR: Error sending KEY_EXCHANGE command to slave\n");
		return 0;

	}
	sKey.SlaveInterKey = 0;
	for(i = 0; i < 8; i++)
		sKey.SlaveInterKey += ((unsigned __int64)sspC.ResponseData[i + 1]) << (i*8);  


	// DLL call to create our key
	if(createSSPHostEncryptionKey(&sKey) == 0){
		printf("ERROR: Cannot Create host keys\n");
		return 0;
	}
	

	*hostKey = sKey.KeyHost; 


	return 1;

}





////////////////////////////////////////////////////////////////////////////////////
//  Function to call dll with ssp command structure. Also controls busy reties
///////////////////////////////////////////////////////////////////////////////////////
int SendSSPCommand(SSP_COMMAND* sp,SSP_COMMAND_INFO* si)
{
	int reTries = 0;
	int i;
	SSP_COMMAND ssp;
	
	/* take a copy for retries  */
	for(i = 0; i < sp->CommandDataLength; i++)
		ssp.CommandData[i] = sp->CommandData[i];  
	ssp.CommandDataLength = sp->CommandDataLength;

	while(reTries < sp->RetryLevel){ 	

		/* dll call  */
		if(sspSendCommand(&sspC,&sspI) == 0)
			return 0;
		/* response OK  */
		if(sspC.ResponseData[0] == rsp_SSP_OK)
			return 255;
		/* retry for busy response  */
		if(sspC.ResponseData[0] == rsp_COMMAND_NOT_PROCESSED && sspC.ResponseDataLength == 2 && sspC.ResponseData[1] == PAYOUT_BUSY){
			Sleep(500); /* delay for next retry */
			/* restore command data as it may have been changed by DLL encryption  */
			for(i = 0; i < ssp.CommandDataLength; i++)
				sp->CommandData[i] = ssp.CommandData[i];  
			sp->CommandDataLength = ssp.CommandDataLength; 
		}

		/* Check for a payout error responses  */
		if(sspC.ResponseData[0] == rsp_COMMAND_NOT_PROCESSED && sspC.ResponseDataLength == 2 && sspC.ResponseData[1] == NOT_ENOUGH_VALUE){
			return NOT_ENOUGH_VALUE;
		}
		if(sspC.ResponseData[0] == rsp_COMMAND_NOT_PROCESSED && sspC.ResponseDataLength == 2 && sspC.ResponseData[1] == CANNOT_PAY_EXACT_AMOUNT){
			return CANNOT_PAY_EXACT_AMOUNT;
		}
		if(sspC.ResponseData[0] == rsp_COMMAND_NOT_PROCESSED && sspC.ResponseDataLength == 2 && sspC.ResponseData[1] == PAYOUT_DISABLED){
			return PAYOUT_DISABLED;
		}


			
		reTries++;
	}

	if(reTries >= sp->RetryLevel)
		return 0;

	return 255;
}

