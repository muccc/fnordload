#ifndef _PAYOUT_COMMANDS_H
#define _PAYOUT_COMMANDS_H

#include "ssp.h"



#define MAX_NUMBER_OF_PAYOUT_VALUES							32

typedef struct{
	unsigned char NumberOfValues;
	unsigned long Values[MAX_NUMBER_OF_PAYOUT_VALUES];
	unsigned long ValueCount[MAX_NUMBER_OF_PAYOUT_VALUES];
	unsigned char NoteRoutes[MAX_NUMBER_OF_PAYOUT_VALUES];
	unsigned char CountryCode[4];
	unsigned char FirmwareVersion[5];
	unsigned long TrueValueMultiplier;
	unsigned long TotalStoredValue;
}PAYOUT_DATA;


typedef enum{
	ROUTE_STORED,
	ROUTE_CASHBOX
}NOTE_ROUTES;

typedef enum{
	NOT_ENOUGH_VALUE = 0x01,
	CANNOT_PAY_EXACT_AMOUNT,
	PAYOUT_BUSY,
	PAYOUT_DISABLED,
}PAYOUT_RSP;


int PollPayoutDevice(PAYOUT_DATA* py);
int GetPayoutData(PAYOUT_DATA* py);
int GetPayoutCountData(PAYOUT_DATA* py);
int SetPayOutAmount(unsigned long payAmount);
int EnablePayout(PAYOUT_DATA* py);
int EmptyPayout(void);


#endif
