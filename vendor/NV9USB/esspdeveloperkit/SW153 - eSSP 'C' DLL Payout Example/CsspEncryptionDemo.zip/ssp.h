#ifndef _SSP_H
#define _SSP_H

typedef struct{
	unsigned short packetTime;
	unsigned char PacketLength;
	unsigned char PacketData[255];
}SSP_PACKET;


typedef struct{
	unsigned char* CommandName;
	unsigned char* LogFileName;
	unsigned char Encrypted;
	SSP_PACKET Transmit;
	SSP_PACKET Receive;
	SSP_PACKET PreEncryptTransmit;
	SSP_PACKET PreEncryptRecieve;
}SSP_COMMAND_INFO;


typedef struct{ 
    unsigned __int64 Generator;
    unsigned __int64 Modulus;
    unsigned __int64 HostInter;
    unsigned __int64 HostRandom;
    unsigned __int64 SlaveInterKey;
    unsigned __int64 SlaveRandom;
    unsigned __int64 KeyHost;
    unsigned __int64 KeySlave;
}SSP_KEYS;

/* structure defs		*/
typedef struct{
	unsigned __int64 FixedKey;
	unsigned __int64 EncryptKey;
}SSP_FULL_KEY;




typedef struct{
	SSP_FULL_KEY Key;
	unsigned long BaudRate;
	unsigned long Timeout;
	unsigned char PortNumber;
	unsigned char SSPAddress;
	unsigned char RetryLevel;
	unsigned char EncryptionStatus;
	unsigned char CommandDataLength;
	unsigned char CommandData[255];
	unsigned char ResponseStatus;
	unsigned char ResponseDataLength;
	unsigned char ResponseData[255];
	unsigned char IgnoreError;
}SSP_COMMAND;


/*      SSP command Headers									*/
#define cmd_SSP_SYNC										0x11
#define cmd_SSP_ENABLE										0x0A
#define cmd_SSP_POLL										0x07
#define cmd_SSP_RESET										0x01
#define cmd_ENABLE_PROTOCOL_VER_EVENTS						0x19

#define cmd_SSP_SET_GENERATOR								0x4A
#define cmd_SSP_SET_MODULUS									0x4B
#define cmd_SSP_REQ_KEY_EXCHANGE							0x4C
#define cmd_SET_PAY_OUT_AMOUNT								0x33
#define cmd_SSP_SET_BNV_INHIBITS							0x02
#define cmd_ENABLE_PAYOUT_DEVICE							0x5C
#define cmd_SSP_SETUP_REQUEST								0x05
#define cmd_SSP_GET_NOTE_AMOUNT								0x35
#define cmd_SSP_GET_NOTE_MIN_PAYOUT							0x3E
#define cmd_SSP_GET_NOTE_ROUTE								0x3C
#define cmd_SSP_SET_NOTE_ROUTE								0x3B
#define cmd_EMPTY_PAYOUT									0x3F

/*		SSP responses										*/
#define rsp_SSP_OK							0xF0
#define rsp_COMMAND_NOT_PROCESSED			0xF5


#define hp_rsp_RESET						0xF1

#define hp_rsp_READNOTE						0xEF
#define hp_rsp_NOTE_CREDIT					0xEE
#define hp_rsp_REJECTING					0xED
#define hp_rsp_REJECTED						0xEC
#define hp_rsp_STACKING						0xCC
#define hp_rsp_STACKED						0xEB
#define hp_rsp_SAFE_JAM						0xEA
#define hp_rsp_UNSAFE_JAM					0xE9
#define hp_rsp_STACKER_FULL					0xE7
#define hp_rsp_NOTE_CLEARED_FRONT			0xE1
#define hp_rsp_NOTE_CLEARED_CASHBOX			0xE2
#define hp_rsp_CASHBOX_REMOVED				0xE3
#define hp_rsp_CASHBOX_REPLACED				0xE4
#define hp_rsp_BARCODE_TICKET_VALIDATED		0xE5
#define hp_rsp_BARCODE_TICKET_ACK			0xD1
#define hp_rsp_DISABLED						0xE8

#define hp_rsp_DISPENSING					0xDA
#define hp_rsp_DISPENSED					0xD2
#define hp_rsp_HALTED						0xD6
#define hp_FLOATING							0xD7
#define hp_FLOATED							0xD8
#define hp_TIME_OUT							0xD9
#define hp_EMPTYING							0xC2
#define hp_EMPTYED							0xC3
#define hp_INPCOMPLETE_PAYOUT				0xDC
#define hp_INPCOMPLETE_FLOAT				0xDD
#define hp_CASHBOX_PAID						0xDE
#define hp_rsp_FRAUD_ATTEMPT				0xE6
#define hp_rsp_NOTE_STORED					0xDB


int SendSSPCommand(SSP_COMMAND* sp,SSP_COMMAND_INFO* si);




#endif